python3 ./tools/fill/fill.py ./target/riscv64/release/zcore riscv64 ./ignored/dump
