//! Interrupts management.

use core::ops::Range;

use crate::drivers::all_irq;
use crate::drivers::prelude::{IrqHandler, IrqPolarity, IrqTriggerMode};
use crate::HalResult;
use alloc::vec::Vec;
use x86_64::instructions::interrupts;

hal_fn_impl! {
    impl mod crate::hal_fn::interrupt {
        fn wait_for_interrupt() {
            let enable = interrupts::are_enabled();
            interrupts::enable_and_hlt();
            if !enable {
                interrupts::disable();
            }
        }

        fn is_valid_irq(gsi: usize) -> bool {
            all_irq().first_unwrap().is_valid_irq(gsi)
        }

        fn intr_on() {
            interrupts::enable();
        }

        fn intr_off() {
            interrupts::disable();
        }

        fn intr_get() -> bool {
            interrupts::are_enabled()
        }

        fn mask_irq(gsi: usize) -> HalResult {
            Ok(all_irq().first_unwrap().mask(gsi)?)
        }

        fn unmask_irq(gsi: usize) -> HalResult {
            Ok(all_irq().first_unwrap().unmask(gsi)?)
        }

        fn configure_irq(gsi: usize, tm: IrqTriggerMode, pol: IrqPolarity) -> HalResult {
            Ok(all_irq().first_unwrap().configure(gsi, tm, pol)?)
        }

        fn register_irq_handler(gsi: usize, handler: IrqHandler) -> HalResult {
            Ok(all_irq().first_unwrap().register_handler(gsi, handler)?)
        }

        fn unregister_irq_handler(gsi: usize) -> HalResult {
            Ok(all_irq().first_unwrap().unregister(gsi)?)
        }

        fn handle_irq(vector: usize) {
            all_irq().first_unwrap().handle_irq(vector as usize);
        }

        fn msi_alloc_block(requested_irqs: usize) -> HalResult<Range<usize>> {
            Ok(all_irq().first_unwrap().msi_alloc_block(requested_irqs)?)
        }

        fn msi_free_block(block: Range<usize>) -> HalResult {
            Ok(all_irq().first_unwrap().msi_free_block(block)?)
        }

        fn msi_register_handler(
            block: Range<usize>,
            msi_id: usize,
            handler: IrqHandler,
        ) -> HalResult {
            Ok(all_irq().first_unwrap().msi_register_handler(block, msi_id, handler)?)
        }

        fn send_ipi(cpuid: usize, reason: usize) -> HalResult {
            trace!("ipi [{}] => [{}]: {:x}", super::cpu::cpu_id(), cpuid, reason);
            panic!("send_ipi unsupported for x86_64");
        }

        fn ipi_reason() -> Vec<usize> {
            panic!("ipi_reason unsupported for x86_64");
        }
    }
}
