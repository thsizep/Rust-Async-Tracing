//! Only Mouse currently.

mod mouse;

pub mod input_event_codes;

pub use mouse::{Mouse, MouseFlags, MouseState};
