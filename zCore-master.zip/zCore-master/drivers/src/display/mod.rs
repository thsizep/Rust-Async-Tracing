//! Only UEFI Display currently.

mod uefi;

pub use uefi::UefiDisplay;
