mod table;
/// call init_symbol_table(str) before using symbol_to_addr()
pub use table::{init_symbol_table, symbol_to_addr, symbol_table_with};