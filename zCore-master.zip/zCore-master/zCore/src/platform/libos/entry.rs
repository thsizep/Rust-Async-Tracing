#[no_mangle]
fn main() {
    crate::primary_main(kernel_hal::KernelConfig);
}
